"""
Jarvis - Advanced Personal AI Assistant
Entry point
"""

import sys
import os

# Ensure the project root is in the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import USE_WAKE_WORD, WAKE_WORDS
from core.speech import speak
from core.listener import listen, init_whisper
from core.brain import init_brain, ask_grok
from features.spotify_ctrl import init_spotify, handle_spotify
from features.homeassistant import init_homeassistant, handle_smart_home
from features.system import (
    wish_me,
    tell_time,
    tell_date,
    system_info,
    open_website,
    search_wikipedia,
    tell_joke,
)
from features.vision import face_detection
from ui.gui import run_gui, status_queue, running


def process_command(query: str):
    """Route the user query to the correct feature."""
    if not query:
        return

    # Spotify has priority for music commands
    if any(k in query for k in ["play", "pause", "resume", "next", "skip", "previous", "volume"]):
        if handle_spotify(query):
            return

    if "time" in query:
        tell_time()
    elif "date" in query or "what day" in query:
        tell_date()
    elif "wikipedia" in query:
        topic = query.replace("wikipedia", "").replace("search", "").strip()
        if not topic:
            speak("What should I search on Wikipedia?")
            topic = listen(status_queue)
        if topic:
            search_wikipedia(topic)
    elif "open youtube" in query:
        open_website("youtube.com")
    elif "open google" in query:
        open_website("google.com")
    elif "open github" in query:
        open_website("github.com")
    elif "system info" in query or "about my computer" in query:
        system_info()
    elif "face" in query or "detect face" in query or "camera" in query:
        face_detection()
    elif any(x in query for x in ["light", "lights", "temperature", "thermostat", "smart home"]):
        handle_smart_home(query)
    elif "joke" in query:
        tell_joke()
    elif any(x in query for x in ["goodbye", "exit", "quit", "shutdown", "go to sleep", "stop listening"]):
        speak("Going offline. Goodbye, sir.")
        global running
        running = False
        os._exit(0)
    elif "who are you" in query:
        speak("I am Jarvis, your personal artificial intelligence assistant.")
    else:
        # Fallback to Grok for intelligent answers
        speak("Let me think...")
        reply = ask_grok(query)
        speak(reply)


def main_loop():
    wish_me()

    while running:
        query = listen(status_queue)

        if not query:
            continue

        # Wake-word filter
        if USE_WAKE_WORD:
            if not any(w in query for w in WAKE_WORDS):
                continue
            for w in WAKE_WORDS:
                query = query.replace(w, "").strip()

        if query:
            process_command(query)


def main():
    print("=" * 50)
    print("  JARVIS - Personal AI Assistant")
    print("=" * 50)

    init_brain()
    init_spotify()
    init_homeassistant()
    init_whisper()

    # Launch with GUI + system tray (falls back to console if GUI missing)
    run_gui(main_loop)


if __name__ == "__main__":
    main()
