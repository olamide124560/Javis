import speech_recognition as sr
from config import USE_LOCAL_WHISPER, WHISPER_MODEL_SIZE

# Optional Whisper
try:
    from faster_whisper import WhisperModel
    import sounddevice as sd
    import numpy as np
    WHISPER_AVAILABLE = True
except ImportError:
    WHISPER_AVAILABLE = False

_whisper_model = None


def init_whisper():
    global _whisper_model
    if USE_LOCAL_WHISPER and WHISPER_AVAILABLE and _whisper_model is None:
        print("Loading Whisper model (first run may take time)...")
        _whisper_model = WhisperModel(WHISPER_MODEL_SIZE, device="cpu", compute_type="int8")
        print("Whisper ready.")


def listen_google(status_queue=None) -> str:
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        if status_queue:
            status_queue.put(("status", "Listening..."))
        r.pause_threshold = 0.8
        r.adjust_for_ambient_noise(source, duration=0.4)
        audio = r.listen(source, phrase_time_limit=7)

    try:
        query = r.recognize_google(audio, language="en-in")
        print(f"You: {query}")
        if status_queue:
            status_queue.put(("user", query))
        return query.lower()
    except Exception:
        return ""


def listen_whisper(status_queue=None) -> str:
    if not _whisper_model:
        return listen_google(status_queue)

    print("Listening (Whisper)...")
    if status_queue:
        status_queue.put(("status", "Listening (local)...") )

    sample_rate = 16000
    duration = 6
    audio = sd.rec(int(duration * sample_rate), samplerate=sample_rate, channels=1, dtype="float32")
    sd.wait()
    audio = audio.flatten()

    segments, _ = _whisper_model.transcribe(audio, language="en", beam_size=5)
    text = " ".join(s.text for s in segments).strip().lower()
    print(f"You: {text}")
    if status_queue:
        status_queue.put(("user", text))
    return text


def listen(status_queue=None) -> str:
    if USE_LOCAL_WHISPER and _whisper_model:
        return listen_whisper(status_queue)
    return listen_google(status_queue)
