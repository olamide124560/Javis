import os
import sys
import asyncio
import tempfile
import pyttsx3
from config import USE_EDGE_TTS, VOICE

# Optional edge-tts
try:
    import edge_tts
    EDGE_TTS_AVAILABLE = True
except ImportError:
    EDGE_TTS_AVAILABLE = False

engine = pyttsx3.init()
engine.setProperty("rate", 175)


async def _edge_speak(text: str):
    communicate = edge_tts.Communicate(text, VOICE)
    with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as f:
        path = f.name
    await communicate.save(path)

    if sys.platform == "win32":
        os.system(f'start /min "" "{path}"')
    else:
        os.system(f"mpg123 -q '{path}' 2>/dev/null || afplay '{path}' 2>/dev/null || paplay '{path}' 2>/dev/null")

    await asyncio.sleep(0.4)
    try:
        os.remove(path)
    except OSError:
        pass


def speak(text: str, status_queue=None):
    """Speak text using the best available TTS engine."""
    print(f"Jarvis: {text}")
    if status_queue:
        status_queue.put(("speak", text))

    if USE_EDGE_TTS and EDGE_TTS_AVAILABLE:
        try:
            asyncio.run(_edge_speak(text))
            return
        except Exception as e:
            print("edge-tts failed, falling back to pyttsx3:", e)

    engine.say(text)
    engine.runAndWait()
