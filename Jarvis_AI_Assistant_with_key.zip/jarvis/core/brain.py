from openai import OpenAI
from config import XAI_API_KEY, XAI_MODEL

client = None
conversation_history = [
    {
        "role": "system",
        "content": (
            "You are Jarvis, a highly capable, slightly witty personal AI assistant "
            "inspired by Iron Man. Keep answers concise and helpful. "
            "Occasionally address the user as 'sir'."
        ),
    }
]


def init_brain():
    global client
    if XAI_API_KEY:
        client = OpenAI(api_key=XAI_API_KEY, base_url="https://api.x.ai/v1")
        print("Grok brain online.")
    else:
        print("Warning: No XAI_API_KEY found. Advanced replies disabled.")


def ask_grok(prompt: str) -> str:
    if not client:
        return "Advanced neural core offline. Please add XAI_API_KEY to your .env file."

    conversation_history.append({"role": "user", "content": prompt})

    try:
        response = client.chat.completions.create(
            model=XAI_MODEL,
            messages=conversation_history,
            temperature=0.7,
            max_tokens=450,
        )
        reply = response.choices[0].message.content.strip()
        conversation_history.append({"role": "assistant", "content": reply})

        # Keep history manageable
        if len(conversation_history) > 14:
            del conversation_history[1:3]

        return reply
    except Exception as e:
        return f"Neural core error: {e}"
