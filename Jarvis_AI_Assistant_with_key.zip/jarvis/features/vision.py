from core.speech import speak

try:
    import cv2
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False


def face_detection():
    if not CV2_AVAILABLE:
        speak("OpenCV is not installed. Face detection unavailable.")
        return

    speak("Activating camera for face detection.")
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        speak("Could not access the camera.")
        return

    cascade = cv2.CascadeClassifier(
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    )

    detected = False
    for _ in range(50):  # roughly 2 seconds
        ret, frame = cap.read()
        if not ret:
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = cascade.detectMultiScale(gray, 1.3, 5)
        if len(faces) > 0:
            detected = True
            break

    cap.release()

    if detected:
        speak("Face detected. Welcome back, sir.")
    else:
        speak("No face detected in the camera feed.")
