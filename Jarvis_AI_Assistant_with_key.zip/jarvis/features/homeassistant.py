import requests
from config import HA_URL, HA_TOKEN
from core.speech import speak

ha_headers = None


def init_homeassistant():
    global ha_headers
    if HA_URL and HA_TOKEN:
        ha_headers = {
            "Authorization": f"Bearer {HA_TOKEN}",
            "Content-Type": "application/json",
        }
        print("Home Assistant configured.")


def _call(domain: str, service: str, entity_id: str = None, data: dict = None) -> bool:
    if not ha_headers:
        return False

    url = f"{HA_URL.rstrip('/')}/api/services/{domain}/{service}"
    payload = data or {}
    if entity_id:
        payload["entity_id"] = entity_id

    try:
        r = requests.post(url, headers=ha_headers, json=payload, timeout=5)
        return r.status_code in (200, 201)
    except Exception:
        return False


def handle_smart_home(query: str):
    if not ha_headers:
        # Simulation fallback
        if "lights on" in query or "turn on the lights" in query:
            speak("Turning lights on (simulation mode).")
        elif "lights off" in query or "turn off the lights" in query:
            speak("Turning lights off (simulation mode).")
        else:
            speak("Home Assistant is not configured. Add HA_URL and HA_TOKEN to .env")
        return

    if "lights on" in query or "turn on the light" in query:
        success = _call("light", "turn_on")
        speak("Lights turned on." if success else "Failed to control lights.")
    elif "lights off" in query or "turn off the light" in query:
        success = _call("light", "turn_off")
        speak("Lights turned off." if success else "Failed to control lights.")
    elif "temperature" in query or "thermostat" in query:
        speak("For precise climate control, specify an entity_id in the code.")
    else:
        speak("Smart home command acknowledged.")
