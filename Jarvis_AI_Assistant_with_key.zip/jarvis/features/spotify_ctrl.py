from config import SPOTIFY_CLIENT_ID, SPOTIFY_CLIENT_SECRET, SPOTIFY_REDIRECT_URI
from core.speech import speak

sp = None

try:
    import spotipy
    from spotipy.oauth2 import SpotifyOAuth
    SPOTIFY_AVAILABLE = True
except ImportError:
    SPOTIFY_AVAILABLE = False


def init_spotify():
    global sp
    if not SPOTIFY_AVAILABLE or not SPOTIFY_CLIENT_ID:
        return

    try:
        sp = spotipy.Spotify(
            auth_manager=SpotifyOAuth(
                client_id=SPOTIFY_CLIENT_ID,
                client_secret=SPOTIFY_CLIENT_SECRET,
                redirect_uri=SPOTIFY_REDIRECT_URI,
                scope="user-modify-playback-state user-read-playback-state user-read-currently-playing",
                open_browser=True,
            )
        )
        print("Spotify connected.")
    except Exception as e:
        print("Spotify init failed:", e)


def handle_spotify(query: str) -> bool:
    """Return True if the command was handled by Spotify."""
    if not sp:
        return False

    try:
        if "play" in query:
            q = query.replace("play", "").replace("on spotify", "").strip()
            if not q:
                sp.start_playback()
                speak("Resuming playback.")
                return True

            results = sp.search(q, limit=1, type="track")
            if results["tracks"]["items"]:
                track = results["tracks"]["items"][0]
                sp.start_playback(uris=[track["uri"]])
                artists = ", ".join(a["name"] for a in track["artists"])
                speak(f"Playing {track['name']} by {artists}")
            else:
                speak("Could not find that track on Spotify.")
            return True

        if "pause" in query or "stop music" in query:
            sp.pause_playback()
            speak("Paused.")
            return True

        if "resume" in query or "continue" in query:
            sp.start_playback()
            speak("Resuming.")
            return True

        if "next" in query or "skip" in query:
            sp.next_track()
            speak("Next track.")
            return True

        if "previous" in query or "back" in query:
            sp.previous_track()
            speak("Previous track.")
            return True

        if "volume" in query:
            playback = sp.current_playback()
            if not playback:
                speak("No active Spotify device.")
                return True
            current = playback["device"]["volume_percent"]
            if "up" in query:
                sp.volume(min(100, current + 15))
                speak("Volume up.")
            elif "down" in query:
                sp.volume(max(0, current - 15))
                speak("Volume down.")
            return True

    except Exception as e:
        speak(f"Spotify error: {str(e)[:100]}")
        return True

    return False
