import datetime
import platform
import webbrowser
import wikipedia
import random
from core.speech import speak


def wish_me():
    hour = datetime.datetime.now().hour
    if hour < 12:
        greeting = "Good morning"
    elif hour < 18:
        greeting = "Good afternoon"
    else:
        greeting = "Good evening"
    speak(f"{greeting}, sir. Jarvis online. All systems nominal.")


def tell_time():
    now = datetime.datetime.now().strftime("%I:%M %p")
    speak(f"The time is {now}")


def tell_date():
    today = datetime.datetime.now().strftime("%A, %B %d, %Y")
    speak(f"Today is {today}")


def system_info():
    speak(f"You are running {platform.system()} {platform.release()}")
    speak(f"Processor: {platform.processor()}")


def open_website(site: str):
    speak(f"Opening {site}")
    webbrowser.open(f"https://{site}")


def search_wikipedia(query: str):
    speak("Searching Wikipedia...")
    try:
        results = wikipedia.summary(query, sentences=2)
        speak("According to Wikipedia...")
        speak(results)
    except Exception:
        speak("Sorry, I could not find reliable information on that topic.")


def tell_joke():
    jokes = [
        "Why don't scientists trust atoms? Because they make up everything.",
        "I told my computer I needed a break. Now it won't stop sending me KitKat ads.",
        "Why did the AI go to therapy? It had too many deep learning issues.",
        "Parallel lines have so much in common. It’s a shame they’ll never meet.",
    ]
    speak(random.choice(jokes))
