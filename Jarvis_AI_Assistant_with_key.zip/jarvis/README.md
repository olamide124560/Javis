# Jarvis – Advanced Personal AI Assistant

A modular, feature-rich voice assistant inspired by Iron Man’s Jarvis.

## Features

- Voice input (Google Speech Recognition or offline **faster-whisper**)
- High-quality neural TTS (`edge-tts`) + offline fallback
- Intelligent replies powered by **xAI Grok**
- Spotify control (play, pause, next, previous, volume, search)
- Home Assistant integration (lights, switches, etc.)
- Face detection (OpenCV)
- Wikipedia search, time/date, system info, jokes
- Modern dark GUI + system tray icon
- Fully modular and easy to extend

## Project Structure

```
jarvis/
├── main.py                 # Entry point
├── config.py               # All settings & toggles
├── requirements.txt
├── .env.example
├── core/
│   ├── speech.py           # Text-to-Speech
│   ├── listener.py         # Speech-to-Text
│   └── brain.py            # Grok AI integration
├── features/
│   ├── spotify_ctrl.py
│   ├── homeassistant.py
│   ├── system.py
│   └── vision.py
└── ui/
    └── gui.py              # GUI + System Tray
```

## Quick Start

1. **Clone / extract** this folder.

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Create your `.env` file**
   ```bash
   cp .env.example .env
   ```
   Then edit `.env` and add your keys:
   - `XAI_API_KEY` → https://console.x.ai
   - Spotify credentials (optional) → https://developer.spotify.com/dashboard
   - Home Assistant URL + Long-Lived Token (optional)

4. **Run**
   ```bash
   python main.py
   ```

## Configuration

Open `config.py` to toggle features:

| Setting              | Description                              |
|----------------------|------------------------------------------|
| `USE_WAKE_WORD`      | Require saying “Jarvis” first            |
| `USE_EDGE_TTS`       | Use high-quality neural voices           |
| `USE_LOCAL_WHISPER`  | Fully offline speech recognition         |
| `VOICE`              | Change the speaking voice                |
| `XAI_MODEL`          | Which Grok model to use                  |

## Example Commands

- “Jarvis, what time is it?”
- “Jarvis, play Bohemian Rhapsody”
- “Jarvis, pause”
- “Jarvis, next track”
- “Jarvis, turn on the lights”
- “Jarvis, search Wikipedia for black holes”
- “Jarvis, detect face”
- “Jarvis, tell me a joke”
- “Jarvis, who won the last World Cup?” → answered by Grok
- “Jarvis, goodbye”

## Notes

- First run with `USE_LOCAL_WHISPER = True` downloads the Whisper model.
- Spotify playback control requires a Premium account.
- Home Assistant needs a Long-Lived Access Token (Profile → Security).
- Closing the window minimizes Jarvis to the system tray.

## Extending

Want to add more features? Just create a new file under `features/` and call it from `main.py` → `process_command()`.

Enjoy your personal Jarvis.
