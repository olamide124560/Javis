# Utility helpers (expand as needed)
