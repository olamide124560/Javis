import queue
import threading
import os
import sys
from PIL import Image, ImageDraw

try:
    import tkinter as tk
    from tkinter import scrolledtext
    import pystray
    GUI_AVAILABLE = True
except ImportError:
    GUI_AVAILABLE = False

status_queue = queue.Queue()
running = True


def create_icon_image():
    img = Image.new("RGB", (64, 64), color=(20, 20, 40))
    d = ImageDraw.Draw(img)
    d.ellipse([8, 8, 56, 56], fill=(0, 180, 255))
    d.text((22, 18), "J", fill="white")
    return img


def run_gui(main_loop_func):
    if not GUI_AVAILABLE:
        print("GUI libraries not available. Running in console mode.")
        main_loop_func()
        return

    root = tk.Tk()
    root.title("Jarvis Control Center")
    root.geometry("540x400")
    root.configure(bg="#0d1117")

    status_label = tk.Label(
        root, text="Status: Starting...", fg="#58a6ff", bg="#0d1117", font=("Segoe UI", 12)
    )
    status_label.pack(pady=10)

    log = scrolledtext.ScrolledText(
        root, height=18, bg="#161b22", fg="#c9d1d9", font=("Consolas", 10)
    )
    log.pack(fill="both", expand=True, padx=12, pady=5)

    def update_gui():
        try:
            while True:
                kind, msg = status_queue.get_nowait()
                if kind == "status":
                    status_label.config(text=f"Status: {msg}")
                elif kind == "user":
                    log.insert(tk.END, f"You: {msg}\n")
                elif kind == "speak":
                    log.insert(tk.END, f"Jarvis: {msg}\n")
                log.see(tk.END)
        except queue.Empty:
            pass
        if running:
            root.after(200, update_gui)

    def on_close():
        root.withdraw()

    root.protocol("WM_DELETE_WINDOW", on_close)
    update_gui()

    # System tray
    def quit_app(icon, item):
        global running
        running = False
        icon.stop()
        root.destroy()
        os._exit(0)

    def show_window(icon, item):
        root.after(0, root.deiconify)

    menu = pystray.Menu(
        pystray.MenuItem("Show Jarvis", show_window, default=True),
        pystray.MenuItem("Quit", quit_app),
    )
    icon = pystray.Icon("Jarvis", create_icon_image(), "Jarvis AI Assistant", menu)

    # Start tray in background
    threading.Thread(target=icon.run, daemon=True).start()

    # Start the voice loop in background
    threading.Thread(target=main_loop_func, daemon=True).start()

    root.mainloop()
