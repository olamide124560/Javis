import os
from dotenv import load_dotenv

load_dotenv()

# ====================== FEATURE TOGGLES ======================
USE_WAKE_WORD = True
WAKE_WORDS = ["jarvis", "hey jarvis", "ok jarvis"]

USE_EDGE_TTS = True
VOICE = "en-US-GuyNeural"          # Try: en-US-JennyNeural, en-GB-RyanNeural, etc.

USE_LOCAL_WHISPER = False          # True = fully offline STT (slower first run)
WHISPER_MODEL_SIZE = "base.en"     # tiny.en | base.en | small.en

XAI_MODEL = "grok-4-1-fast-reasoning"

# ====================== API KEYS ======================
XAI_API_KEY = os.getenv("XAI_API_KEY")
SPOTIFY_CLIENT_ID = os.getenv("SPOTIFY_CLIENT_ID")
SPOTIFY_CLIENT_SECRET = os.getenv("SPOTIFY_CLIENT_SECRET")
SPOTIFY_REDIRECT_URI = os.getenv("SPOTIFY_REDIRECT_URI", "http://127.0.0.1:8888/callback")
HA_URL = os.getenv("HA_URL")
HA_TOKEN = os.getenv("HA_TOKEN")
